package isi.deso.tp.model;

public enum EstadoPedidoEnum {
    RECIBIDO,
    PREPARANDO,
    CANCELADO,
    ENVIADO,
    ENTREGADO
}
