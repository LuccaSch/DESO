package isi.deso.tp.service;

public class ItemMenuController {

    /*
        FALTAN METODOS:
        mostrarLista()
        crearNuevo(nombre, direccion, coordenadas) no deben poder crear con identificador, sino que la deberían de manera automática.
        eliminar(int id)
        modificar(nombre, direccion, coordenadas)
        buscar(int id)

        VER EJEMPLO EN VendedorController
     */
}
