package isi.deso.tp.model;

public enum Tamano {
    CHICA,
    MEDIANA,
    GRANDE
}
