package isi.deso.tp.ui;

import isi.deso.tp.dao.ClienteMemoryDAO;
import isi.deso.tp.dao.ItemMenuMemoryDAO;
import isi.deso.tp.dao.PedidoMemoryDAO;
import isi.deso.tp.dao.VendedorDAO;
import isi.deso.tp.dao.VendedorMemoryDAO;
import isi.deso.tp.exception.VendedorNoEncontradoException;
import isi.deso.tp.model.BebidaAlcoholica;
import isi.deso.tp.model.BebidaSinAlcohol;
import isi.deso.tp.model.Categoria;
import isi.deso.tp.model.Cliente;
import isi.deso.tp.model.Coordenada;
import isi.deso.tp.model.ItemMenu;
import isi.deso.tp.model.ItemPedido;
import isi.deso.tp.model.Pedido;
import isi.deso.tp.model.Plato;
import isi.deso.tp.model.Tamano;
import isi.deso.tp.model.Vendedor;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.table.DefaultTableModel;
import isi.deso.tp.service.ClienteController;
import isi.deso.tp.service.ItemMenuController;
import isi.deso.tp.service.ItemPedidoController;
import isi.deso.tp.service.VendedorController;
import isi.deso.tp.service.PedidoController;

public class Inicio extends javax.swing.JFrame {

    List<Integer> cantidadCarrito = new ArrayList();
    DefaultTableModel modelo = new DefaultTableModel();
    DefaultTableModel modeloSinAlcohol = new DefaultTableModel();
    DefaultListModel modeloListaItemVendedor = new DefaultListModel();
    DefaultListModel modeloListaClientePedido = new DefaultListModel();
    DefaultListModel modeloListaVendedorItem = new DefaultListModel();
    DefaultTableModel modeloAlcohol = new DefaultTableModel();
    DefaultTableModel modeloCarrito = new DefaultTableModel();
    DefaultTableModel modeloPlato = new DefaultTableModel();
    DefaultTableModel modeloCliente = new DefaultTableModel();
    DefaultTableModel modeloPedido = new DefaultTableModel();
    List<Vendedor> listaVendedores = new ArrayList<>();
    List<BebidaSinAlcohol> listaSinAlcohol = new ArrayList<>();
    List<BebidaAlcoholica> listaAlcohol = new ArrayList<>();
    List<ItemMenu> listaItem = new ArrayList<>();
    List<ItemMenu> listaCarrito = new ArrayList<>();
    List<Cliente> listaClientes = new ArrayList<>();
    List<Plato> listaPlatos = new ArrayList<>();
    List<ItemPedido> listaItemPedido = new ArrayList<>();
    VendedorController vendedorController;
    ClienteController clienteController;
    ItemMenuController itemMenuController;
    PedidoController pedidoController;
    ItemPedidoController itemPedidoController;
    private String vendedorABuscar;

    /**
     * Creates new form Inicio
     */
    public Inicio() {
        initComponents();
        this.setTitle("Incio");
        this.setLocationRelativeTo(null);

        panelAlcohol.setVisible(false);
        panelSinAlcohol.setVisible(false);
        panelPlato.setVisible(false);
        vendedorController = new VendedorController(VendedorMemoryDAO.getInstance());
        clienteController = new ClienteController(ClienteMemoryDAO.getInstance());
        itemMenuController = new ItemMenuController(ItemMenuMemoryDAO.getInstance());
        pedidoController = new PedidoController(PedidoMemoryDAO.getInstance());
        itemPedidoController = new ItemPedidoController();
        iniciarListaItems();
        iniciarListaClientes();
        iniciarListaVendedores();
        modeloCliente.addColumn("NOMBRE");
        modeloCliente.addColumn("CUIT");
        modeloCliente.addColumn("EMAIL");
        modeloCliente.addColumn("DIRECCION");
        modeloCliente.addColumn("COORDENADA");

        modeloCarrito.addColumn("Nombre");
        modeloCarrito.addColumn("Cantidad");
        modeloCarrito.addColumn("Precio");

        modelo.addColumn("NOMBRE");
        modelo.addColumn("DIRECCION");
        modelo.addColumn("ID");
        modelo.addColumn("ItemMenu");

        modeloAlcohol.addColumn("Graduación");
        modeloAlcohol.addColumn("Volumen");
        modeloAlcohol.addColumn("Id");
        modeloAlcohol.addColumn("Nombre");
        modeloAlcohol.addColumn("Precio");
        modeloAlcohol.addColumn("Categoria");
        modeloAlcohol.addColumn("Vendedor");

        modeloSinAlcohol.addColumn("Tamaño");
        modeloSinAlcohol.addColumn("Volumen");
        modeloSinAlcohol.addColumn("Id");
        modeloSinAlcohol.addColumn("Nombre");
        modeloSinAlcohol.addColumn("Precio");
        modeloSinAlcohol.addColumn("Vendedor");

        modeloPedido.addColumn("Cliente");
        modeloPedido.addColumn("Precio");
        modeloPedido.addColumn("Items");

        modeloPlato.addColumn("Calorias");
        modeloPlato.addColumn("AptoCeliaco");
        modeloPlato.addColumn("AptoVegano");
        modeloPlato.addColumn("Nombre");
        modeloPlato.addColumn("Precio");
        modeloPlato.addColumn("Vendedor");

        iniciarTablaPlatos();
        iniciarTablaSinAlcohol();
        iniciarTablaAlcohol();
        iniciarTablaCliente();
        iniciarTablaCarrito();
        iniciarTablaPedido();
        iniciarTabla();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel4 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        txtNombreCliente = new javax.swing.JTextField();
        txtCuitCliente = new javax.swing.JTextField();
        txtEmailCliente = new javax.swing.JTextField();
        txtDireccionCliente = new javax.swing.JTextField();
        SpinnerLongCliente = new javax.swing.JSpinner();
        SpinnerLatCliente = new javax.swing.JSpinner();
        jScrollPane5 = new javax.swing.JScrollPane();
        tableCliente = new javax.swing.JTable();
        btnCrearCliente = new javax.swing.JButton();
        btnBorrarCliente = new javax.swing.JButton();
        btnActualizarCliente = new javax.swing.JButton();
        jLabel34 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        txtBuscadorCliente = new javax.swing.JTextField();
        btnLimpiarCliente = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaVend = new javax.swing.JTable();
        btncrearVendedor = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        txtDireccion = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        spinerId = new javax.swing.JSpinner();
        spnLat = new javax.swing.JSpinner();
        spnLong = new javax.swing.JSpinner();
        btnBorrar = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        listItems = new javax.swing.JList<>();
        btnActualizarVendedor = new javax.swing.JButton();
        jLabel33 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        btnLimpiarBusquedaVendedor = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        btnBebida = new javax.swing.JRadioButton();
        btnAlcohol = new javax.swing.JRadioButton();
        btnplato = new javax.swing.JRadioButton();
        panelAlcohol = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        spnnerGraduacion = new javax.swing.JSpinner();
        spnnerVol = new javax.swing.JSpinner();
        txtNombreAlcohol = new javax.swing.JTextField();
        spnnerPrecioA = new javax.swing.JSpinner();
        jLabel6 = new javax.swing.JLabel();
        cmbCategoriaA = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableAlcohol = new javax.swing.JTable();
        btnCrearAlcohol = new javax.swing.JButton();
        btnBorrarAlcohol = new javax.swing.JButton();
        spnnerIdAlcohol = new javax.swing.JSpinner();
        btnActualizarAlcohol = new javax.swing.JButton();
        jLabel42 = new javax.swing.JLabel();
        txtBuscadorAlcohol = new javax.swing.JTextField();
        btnBuscarAlcohol = new javax.swing.JButton();
        btnLimpiarBusquedaAlcohol = new javax.swing.JButton();
        jScrollPane11 = new javax.swing.JScrollPane();
        listVendedorAlcohol = new javax.swing.JList<>();
        jLabel44 = new javax.swing.JLabel();
        panelSinAlcohol = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        spnerVolSinAlcohol = new javax.swing.JSpinner();
        spnIdSinAlcohol = new javax.swing.JSpinner();
        txtNombreSinAlcohol = new javax.swing.JTextField();
        spinnerPrecioSinAlcohol = new javax.swing.JSpinner();
        jLabel19 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tableSinAlcohol = new javax.swing.JTable();
        btnBebidaSinAlcohol = new javax.swing.JButton();
        btnBorrarSinAlcohol = new javax.swing.JButton();
        cmbBoxSinAlcohol = new javax.swing.JComboBox<>();
        btnActualizarSinAlcohol = new javax.swing.JButton();
        jLabel43 = new javax.swing.JLabel();
        txtBuscadorSinAlcohol = new javax.swing.JTextField();
        btnBuscarSinAlcohol = new javax.swing.JButton();
        btnLimpiarSinAlcohol = new javax.swing.JButton();
        jLabel45 = new javax.swing.JLabel();
        jScrollPane12 = new javax.swing.JScrollPane();
        listVendedorSinAlcohol = new javax.swing.JList<>();
        panelPlato = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        tablaPlato = new javax.swing.JTable();
        btnCrearPlato = new javax.swing.JButton();
        BtnBorrarPlato = new javax.swing.JButton();
        BtnActualizarPlato = new javax.swing.JButton();
        jLabel17 = new javax.swing.JLabel();
        spinnerCalorias = new javax.swing.JSpinner();
        jLabel23 = new javax.swing.JLabel();
        btnAptoCeliaco = new javax.swing.JToggleButton();
        jLabel28 = new javax.swing.JLabel();
        btnAptoVegano = new javax.swing.JToggleButton();
        jLabel29 = new javax.swing.JLabel();
        txtNombrePlato = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        SpinnerPrecioPlato = new javax.swing.JSpinner();
        jLabel31 = new javax.swing.JLabel();
        jScrollPane13 = new javax.swing.JScrollPane();
        listVendedorPlato = new javax.swing.JList<>();
        jLabel46 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        txtBuscadorPlato = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        spinnerCarrito = new javax.swing.JSpinner();
        btnAgregarCarrito = new javax.swing.JButton();
        jScrollPane8 = new javax.swing.JScrollPane();
        tablaCarrito = new javax.swing.JTable();
        jScrollPane9 = new javax.swing.JScrollPane();
        tablaPedido = new javax.swing.JTable();
        jScrollPane10 = new javax.swing.JScrollPane();
        listItemsPedido = new javax.swing.JList<>();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        listClientesPedido = new javax.swing.JList<>();
        btnCrearPedido = new javax.swing.JButton();
        btnBorrarPedido = new javax.swing.JButton();
        btnActualizarPedido = new javax.swing.JButton();
        cmbBoxFormaPago = new javax.swing.JComboBox<>();
        jLabel47 = new javax.swing.JLabel();
        txtBuscadorPedido = new javax.swing.JTextField();
        btnBuscarPedido = new javax.swing.JButton();
        btnLimpiarBusquedaPedido = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel22.setText("Nombre:");

        jLabel24.setText("CUIT:");

        jLabel25.setText("Email:");

        jLabel26.setText("Dirección:");

        jLabel27.setText("Coordenada:");

        txtNombreCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreClienteActionPerformed(evt);
            }
        });

        SpinnerLongCliente.setModel(new javax.swing.SpinnerNumberModel(0.0d, 0.0d, null, 0.1d));

        SpinnerLatCliente.setModel(new javax.swing.SpinnerNumberModel(0.0d, 0.0d, null, 0.1d));

        tableCliente.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane5.setViewportView(tableCliente);

        btnCrearCliente.setText("Crear");
        btnCrearCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCrearClienteActionPerformed(evt);
            }
        });

        btnBorrarCliente.setText("Borrar");
        btnBorrarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBorrarClienteActionPerformed(evt);
            }
        });

        btnActualizarCliente.setText("Actualizar");
        btnActualizarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarClienteActionPerformed(evt);
            }
        });

        jLabel34.setText("Buscador");

        jButton2.setText("Buscar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        btnLimpiarCliente.setText("Limpiar");
        btnLimpiarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarClienteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 657, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel25)
                                .addGap(18, 18, 18)
                                .addComponent(txtEmailCliente))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel22)
                                    .addComponent(jLabel24))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtNombreCliente)
                                    .addComponent(txtCuitCliente))))
                        .addGap(357, 357, 357)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel21)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(btnCrearCliente)
                                .addGap(18, 18, 18)
                                .addComponent(btnBorrarCliente))))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel26)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtDireccionCliente))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel27)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(SpinnerLongCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(SpinnerLatCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel34)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtBuscadorCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton2)))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnActualizarCliente)
                    .addComponent(btnLimpiarCliente))
                .addContainerGap(251, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel22)
                            .addComponent(txtNombreCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel24)
                            .addComponent(txtCuitCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtEmailCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel25))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel26)
                            .addComponent(txtDireccionCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel27)
                            .addComponent(SpinnerLongCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SpinnerLatCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel34)
                            .addComponent(jButton2)
                            .addComponent(txtBuscadorCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnLimpiarCliente)))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel21)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnCrearCliente)
                            .addComponent(btnBorrarCliente)
                            .addComponent(btnActualizarCliente))))
                .addGap(45, 45, 45)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 335, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1014, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Clientes", jPanel4);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tablaVend.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Nombre", "Dirección", "itemMenu"
            }
        ));
        jScrollPane2.setViewportView(tablaVend);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 250, 730, 190));

        btncrearVendedor.setText("Crear Vendedor");
        btncrearVendedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncrearVendedorActionPerformed(evt);
            }
        });
        jPanel1.add(btncrearVendedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 0, -1, -1));

        jLabel1.setText("Nombre:");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jLabel2.setText("Dirección:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, -1, -1));

        jLabel3.setText("Id:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, -1, -1));
        jPanel1.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 0, 140, -1));
        jPanel1.add(txtDireccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 30, 140, -1));

        jLabel4.setText("Coordenada:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, -1, -1));

        spinerId.setModel(new javax.swing.SpinnerNumberModel(0, 0, null, 1));
        jPanel1.add(spinerId, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 60, 140, -1));

        spnLat.setModel(new javax.swing.SpinnerNumberModel(0.1d, 0.1d, 1000000.1d, 0.5d));
        jPanel1.add(spnLat, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 90, -1, -1));

        spnLong.setModel(new javax.swing.SpinnerNumberModel(0.1d, 0.1d, 100000.1d, 0.5d));
        jPanel1.add(spnLong, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 90, -1, -1));

        btnBorrar.setText("Borrar");
        btnBorrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBorrarActionPerformed(evt);
            }
        });
        jPanel1.add(btnBorrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 0, -1, -1));

        jLabel20.setText("ItemMenu:");
        jPanel1.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, -1, -1));

        listItems.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane4.setViewportView(listItems);

        jPanel1.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 120, 130, 110));

        btnActualizarVendedor.setText("Actualizar");
        btnActualizarVendedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarVendedorActionPerformed(evt);
            }
        });
        jPanel1.add(btnActualizarVendedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 0, -1, -1));

        jLabel33.setText("Buscador");
        jPanel1.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 210, -1, -1));

        jTextField1.setText("BuscadorVendedores");
        jTextField1.setName("buscadorDeVendedores"); // NOI18N
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 210, 190, -1));

        jButton1.setText("Buscar");
        jButton1.setName("Buscar"); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 210, -1, -1));

        btnLimpiarBusquedaVendedor.setText("Limpiar");
        btnLimpiarBusquedaVendedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarBusquedaVendedorActionPerformed(evt);
            }
        });
        jPanel1.add(btnLimpiarBusquedaVendedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 210, -1, -1));

        jTabbedPane1.addTab("Vendedores", jPanel1);

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        buttonGroup1.add(btnBebida);
        btnBebida.setText("Bebida sin alcohol");
        btnBebida.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBebidaActionPerformed(evt);
            }
        });
        jPanel2.add(btnBebida, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 0, -1, -1));

        buttonGroup1.add(btnAlcohol);
        btnAlcohol.setText("Bebida con alcohol");
        btnAlcohol.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAlcoholActionPerformed(evt);
            }
        });
        jPanel2.add(btnAlcohol, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 30, -1, -1));

        buttonGroup1.add(btnplato);
        btnplato.setText("Plato");
        btnplato.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnplatoActionPerformed(evt);
            }
        });
        jPanel2.add(btnplato, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 60, -1, -1));

        jLabel5.setText("Graduación:");

        jLabel7.setText("Volumen:");

        jLabel8.setText("Id:");

        jLabel9.setText("Nombre:");

        jLabel10.setText("Precio:");

        jLabel11.setText("Categoria:");

        spnnerGraduacion.setModel(new javax.swing.SpinnerNumberModel(0, 0, null, 1));

        spnnerVol.setModel(new javax.swing.SpinnerNumberModel(0.5d, 0.5d, null, 0.5d));

        spnnerPrecioA.setModel(new javax.swing.SpinnerNumberModel(0.5d, 0.5d, 1.00000001E7d, 0.5d));

        jLabel6.setText("usd");

        cmbCategoriaA.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbCategoriaA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbCategoriaAActionPerformed(evt);
            }
        });

        tableAlcohol.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tableAlcohol);

        btnCrearAlcohol.setText("Crear");
        btnCrearAlcohol.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCrearAlcoholActionPerformed(evt);
            }
        });

        btnBorrarAlcohol.setText("Borrar");
        btnBorrarAlcohol.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBorrarAlcoholActionPerformed(evt);
            }
        });

        spnnerIdAlcohol.setModel(new javax.swing.SpinnerNumberModel());

        btnActualizarAlcohol.setText("Actualizar");
        btnActualizarAlcohol.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarAlcoholActionPerformed(evt);
            }
        });

        jLabel42.setText("Buscador:");

        btnBuscarAlcohol.setText("Buscar");
        btnBuscarAlcohol.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarAlcoholActionPerformed(evt);
            }
        });

        btnLimpiarBusquedaAlcohol.setText("Limpiar");
        btnLimpiarBusquedaAlcohol.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarBusquedaAlcoholActionPerformed(evt);
            }
        });

        listVendedorAlcohol.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane11.setViewportView(listVendedorAlcohol);

        jLabel44.setText("Vendedor:");

        javax.swing.GroupLayout panelAlcoholLayout = new javax.swing.GroupLayout(panelAlcohol);
        panelAlcohol.setLayout(panelAlcoholLayout);
        panelAlcoholLayout.setHorizontalGroup(
            panelAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelAlcoholLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelAlcoholLayout.createSequentialGroup()
                        .addGroup(panelAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelAlcoholLayout.createSequentialGroup()
                                .addGroup(panelAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(panelAlcoholLayout.createSequentialGroup()
                                        .addComponent(jLabel7)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(spnnerVol, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(panelAlcoholLayout.createSequentialGroup()
                                        .addComponent(jLabel9)
                                        .addGap(22, 22, 22)
                                        .addComponent(txtNombreAlcohol, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(panelAlcoholLayout.createSequentialGroup()
                                .addGroup(panelAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(panelAlcoholLayout.createSequentialGroup()
                                        .addComponent(jLabel5)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(spnnerGraduacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(panelAlcoholLayout.createSequentialGroup()
                                        .addComponent(jLabel10)
                                        .addGap(33, 33, 33)
                                        .addComponent(spnnerPrecioA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(panelAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(panelAlcoholLayout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(jLabel6)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelAlcoholLayout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel44)
                                        .addGap(18, 18, Short.MAX_VALUE)))))
                        .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(205, 205, 205)
                        .addGroup(panelAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnActualizarAlcohol)
                            .addGroup(panelAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(btnBorrarAlcohol)
                                .addComponent(btnCrearAlcohol))))
                    .addGroup(panelAlcoholLayout.createSequentialGroup()
                        .addGroup(panelAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(panelAlcoholLayout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(spnnerIdAlcohol, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelAlcoholLayout.createSequentialGroup()
                                .addComponent(jLabel11)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(cmbCategoriaA, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel42)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtBuscadorAlcohol, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnBuscarAlcohol)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnLimpiarBusquedaAlcohol)
                        .addGap(29, 29, 29))))
            .addGroup(panelAlcoholLayout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 623, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        panelAlcoholLayout.setVerticalGroup(
            panelAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelAlcoholLayout.createSequentialGroup()
                .addGroup(panelAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panelAlcoholLayout.createSequentialGroup()
                        .addGroup(panelAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel5)
                                .addComponent(spnnerGraduacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel44))
                            .addGroup(panelAlcoholLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(btnCrearAlcohol)))
                        .addGroup(panelAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelAlcoholLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(spnnerVol, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8)
                                    .addComponent(spnnerIdAlcohol, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel9)
                                    .addComponent(txtNombreAlcohol, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel10)
                                    .addComponent(spnnerPrecioA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel11)
                                    .addComponent(cmbCategoriaA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(panelAlcoholLayout.createSequentialGroup()
                                .addGap(15, 15, 15)
                                .addComponent(btnBorrarAlcohol)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnActualizarAlcohol))))
                    .addGroup(panelAlcoholLayout.createSequentialGroup()
                        .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addGap(75, 75, 75)
                        .addGroup(panelAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel42)
                            .addComponent(txtBuscadorAlcohol, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnBuscarAlcohol)
                            .addComponent(btnLimpiarBusquedaAlcohol))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel2.add(panelAlcohol, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 670, 420));

        jLabel12.setText("Tamaño:");

        jLabel13.setText("Volumen:");

        jLabel14.setText("Id:");

        jLabel15.setText("Nombre:");

        jLabel16.setText("Precio:");

        spnerVolSinAlcohol.setModel(new javax.swing.SpinnerNumberModel(0.1d, 0.1d, 1.00000000000001E13d, 0.5d));

        spnIdSinAlcohol.setModel(new javax.swing.SpinnerNumberModel());

        spinnerPrecioSinAlcohol.setModel(new javax.swing.SpinnerNumberModel(0.1d, 0.1d, 1.0000000000001E12d, 0.5d));

        jLabel19.setText("usd");

        tableSinAlcohol.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(tableSinAlcohol);

        btnBebidaSinAlcohol.setText("Crear");
        btnBebidaSinAlcohol.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBebidaSinAlcoholActionPerformed(evt);
            }
        });

        btnBorrarSinAlcohol.setText("Borrar");
        btnBorrarSinAlcohol.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBorrarSinAlcoholActionPerformed(evt);
            }
        });

        cmbBoxSinAlcohol.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "CHICA", "MEDIANA", "GRANDE" }));

        btnActualizarSinAlcohol.setText("Actualizar");
        btnActualizarSinAlcohol.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarSinAlcoholActionPerformed(evt);
            }
        });

        jLabel43.setText("Buscador:");

        btnBuscarSinAlcohol.setText("Buscar");
        btnBuscarSinAlcohol.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarSinAlcoholActionPerformed(evt);
            }
        });

        btnLimpiarSinAlcohol.setText("Limpiar");
        btnLimpiarSinAlcohol.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarSinAlcoholActionPerformed(evt);
            }
        });

        jLabel45.setText("Vendedor:");

        listVendedorSinAlcohol.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane12.setViewportView(listVendedorSinAlcohol);

        javax.swing.GroupLayout panelSinAlcoholLayout = new javax.swing.GroupLayout(panelSinAlcohol);
        panelSinAlcohol.setLayout(panelSinAlcoholLayout);
        panelSinAlcoholLayout.setHorizontalGroup(
            panelSinAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelSinAlcoholLayout.createSequentialGroup()
                .addGroup(panelSinAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelSinAlcoholLayout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(spnIdSinAlcohol, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelSinAlcoholLayout.createSequentialGroup()
                        .addGroup(panelSinAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12)
                            .addComponent(jLabel13))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelSinAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(spnerVolSinAlcohol, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmbBoxSinAlcohol, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelSinAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelSinAlcoholLayout.createSequentialGroup()
                        .addComponent(jLabel18)
                        .addContainerGap(353, Short.MAX_VALUE))
                    .addGroup(panelSinAlcoholLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel45)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(panelSinAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnBorrarSinAlcohol, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnActualizarSinAlcohol, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnBebidaSinAlcohol, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(38, 38, 38))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelSinAlcoholLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel43)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtBuscadorSinAlcohol, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnBuscarSinAlcohol)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnLimpiarSinAlcohol)
                .addGap(10, 10, 10))
            .addGroup(panelSinAlcoholLayout.createSequentialGroup()
                .addGroup(panelSinAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelSinAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(panelSinAlcoholLayout.createSequentialGroup()
                            .addComponent(jLabel15)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(txtNombreSinAlcohol))
                        .addGroup(panelSinAlcoholLayout.createSequentialGroup()
                            .addComponent(jLabel16)
                            .addGap(18, 18, 18)
                            .addComponent(spinnerPrecioSinAlcohol, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jLabel19)))
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 624, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        panelSinAlcoholLayout.setVerticalGroup(
            panelSinAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelSinAlcoholLayout.createSequentialGroup()
                .addGroup(panelSinAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelSinAlcoholLayout.createSequentialGroup()
                        .addGroup(panelSinAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelSinAlcoholLayout.createSequentialGroup()
                                .addGroup(panelSinAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel12)
                                    .addComponent(jLabel18)
                                    .addComponent(cmbBoxSinAlcohol, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel45))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelSinAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel13)
                                    .addComponent(spnerVolSinAlcohol, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelSinAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel14)
                                    .addComponent(spnIdSinAlcohol, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelSinAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel15)
                                    .addComponent(txtNombreSinAlcohol, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(panelSinAlcoholLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelSinAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel16)
                            .addComponent(spinnerPrecioSinAlcohol, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel19)))
                    .addGroup(panelSinAlcoholLayout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(btnBebidaSinAlcohol)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnBorrarSinAlcohol)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnActualizarSinAlcohol)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelSinAlcoholLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel43)
                    .addComponent(txtBuscadorSinAlcohol, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscarSinAlcohol)
                    .addComponent(btnLimpiarSinAlcohol))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.add(panelSinAlcohol, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 670, 420));

        tablaPlato.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane6.setViewportView(tablaPlato);

        btnCrearPlato.setText("Crear");
        btnCrearPlato.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCrearPlatoActionPerformed(evt);
            }
        });

        BtnBorrarPlato.setText("Borrar");
        BtnBorrarPlato.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnBorrarPlatoActionPerformed(evt);
            }
        });

        BtnActualizarPlato.setText("Actualizar");

        jLabel17.setText("Calorias:");

        jLabel23.setText("AptoCeliaco");

        btnAptoCeliaco.setText("Apto");

        jLabel28.setText("AptoVegano:");

        btnAptoVegano.setText("Apto");

        jLabel29.setText("Nombre:");

        jLabel30.setText("Precio:");

        SpinnerPrecioPlato.setModel(new javax.swing.SpinnerNumberModel(0.5d, 0.0d, 1.0E9d, 0.5d));

        jLabel31.setText("Usd");

        listVendedorPlato.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane13.setViewportView(listVendedorPlato);

        jLabel46.setText("vendedor:");

        jLabel32.setText("Buscador:");

        jButton3.setText("Buscar");

        jButton4.setText("Limpiar");

        javax.swing.GroupLayout panelPlatoLayout = new javax.swing.GroupLayout(panelPlato);
        panelPlato.setLayout(panelPlatoLayout);
        panelPlatoLayout.setHorizontalGroup(
            panelPlatoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelPlatoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelPlatoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 639, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(panelPlatoLayout.createSequentialGroup()
                        .addGroup(panelPlatoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelPlatoLayout.createSequentialGroup()
                                .addGroup(panelPlatoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel28)
                                    .addComponent(jLabel29))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelPlatoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(panelPlatoLayout.createSequentialGroup()
                                        .addComponent(SpinnerPrecioPlato, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel31))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelPlatoLayout.createSequentialGroup()
                                        .addGroup(panelPlatoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtNombrePlato, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(btnAptoVegano)
                                            .addGroup(panelPlatoLayout.createSequentialGroup()
                                                .addGap(0, 0, Short.MAX_VALUE)
                                                .addComponent(jLabel46, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(79, 79, 79))))
                            .addGroup(panelPlatoLayout.createSequentialGroup()
                                .addGroup(panelPlatoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(panelPlatoLayout.createSequentialGroup()
                                        .addComponent(jLabel17)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(spinnerCalorias, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(panelPlatoLayout.createSequentialGroup()
                                        .addComponent(jLabel23)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnAptoCeliaco))
                                    .addComponent(jLabel30))
                                .addGap(18, 18, Short.MAX_VALUE)))
                        .addGroup(panelPlatoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(BtnBorrarPlato)
                            .addComponent(btnCrearPlato)
                            .addComponent(BtnActualizarPlato)
                            .addGroup(panelPlatoLayout.createSequentialGroup()
                                .addGap(88, 88, 88)
                                .addComponent(jButton4))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelPlatoLayout.createSequentialGroup()
                        .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(38, 38, 38)
                        .addComponent(txtBuscadorPlato, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton3)
                        .addGap(54, 54, 54)))
                .addGap(0, 25, Short.MAX_VALUE))
        );
        panelPlatoLayout.setVerticalGroup(
            panelPlatoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelPlatoLayout.createSequentialGroup()
                .addGroup(panelPlatoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelPlatoLayout.createSequentialGroup()
                        .addGroup(panelPlatoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel17)
                            .addComponent(spinnerCalorias, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelPlatoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel23)
                            .addComponent(btnAptoCeliaco)
                            .addComponent(jLabel46))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelPlatoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel28)
                            .addComponent(btnAptoVegano))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelPlatoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel29)
                            .addComponent(txtNombrePlato, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelPlatoLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(panelPlatoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelPlatoLayout.createSequentialGroup()
                                .addComponent(btnCrearPlato)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(BtnBorrarPlato)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(BtnActualizarPlato))
                            .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelPlatoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel30)
                    .addGroup(panelPlatoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(SpinnerPrecioPlato, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel31)
                        .addComponent(jButton4)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 19, Short.MAX_VALUE)
                .addGroup(panelPlatoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel32)
                    .addComponent(txtBuscadorPlato, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel2.add(panelPlato, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 670, 420));

        jTabbedPane1.addTab("ItemMenu", jPanel2);

        jLabel36.setText("Cliente:");

        jLabel37.setText("Lista Item:");

        jLabel39.setText("Forma de pago:");

        spinnerCarrito.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));

        btnAgregarCarrito.setText("Agregar Carrito");
        btnAgregarCarrito.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarCarritoActionPerformed(evt);
            }
        });

        tablaCarrito.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane8.setViewportView(tablaCarrito);

        tablaPedido.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane9.setViewportView(tablaPedido);

        listItemsPedido.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        listItemsPedido.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jScrollPane10.setViewportView(listItemsPedido);

        jLabel40.setText("Carrito:");

        jLabel41.setText("Cantidad Item:");

        listClientesPedido.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane7.setViewportView(listClientesPedido);

        btnCrearPedido.setText("Crear");
        btnCrearPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCrearPedidoActionPerformed(evt);
            }
        });

        btnBorrarPedido.setText("Borrar");
        btnBorrarPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBorrarPedidoActionPerformed(evt);
            }
        });

        btnActualizarPedido.setText("Actualizar");
        btnActualizarPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarPedidoActionPerformed(evt);
            }
        });

        cmbBoxFormaPago.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Efectivo", "MercadoPago", "Transferencia" }));

        jLabel47.setText("Buscador:");

        btnBuscarPedido.setText("Buscar");
        btnBuscarPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarPedidoActionPerformed(evt);
            }
        });

        btnLimpiarBusquedaPedido.setText("Limpiar");
        btnLimpiarBusquedaPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarBusquedaPedidoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel36)
                                    .addComponent(jLabel38))
                                .addGap(55, 55, 55)
                                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel37))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(8, 8, 8)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(btnBorrarPedido)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addComponent(jLabel39)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(cmbBoxFormaPago, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(180, 180, 180)
                                        .addComponent(btnCrearPedido))
                                    .addComponent(btnActualizarPedido))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(45, 45, 45)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel41)
                                .addGap(18, 18, 18)
                                .addComponent(spinnerCarrito, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(btnAgregarCarrito))
                        .addGap(275, 275, 275))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel35)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(8, 8, 8)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addComponent(jLabel47)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtBuscadorPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(btnBuscarPedido)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(btnLimpiarBusquedaPedido))
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 427, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(78, 78, 78)
                                        .addComponent(jLabel40)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(48, 48, 48)
                                .addComponent(jLabel36)
                                .addGap(53, 53, 53)
                                .addComponent(jLabel38))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(15, 15, 15)
                                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(60, 60, 60)
                        .addComponent(jLabel39)
                        .addGap(0, 31, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel35)
                        .addGap(26, 26, 26)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel37)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(spinnerCarrito, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel41))
                                .addGap(18, 18, 18)
                                .addComponent(btnAgregarCarrito))
                            .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnCrearPedido)
                            .addComponent(cmbBoxFormaPago, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnBorrarPedido)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel40)
                            .addComponent(btnActualizarPedido))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 312, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel47)
                    .addComponent(txtBuscadorPedido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscarPedido)
                    .addComponent(btnLimpiarBusquedaPedido))
                .addContainerGap(879, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Pedido", jPanel3);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btncrearVendedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncrearVendedorActionPerformed
        // TODO add your handling code here:
        Vendedor v = new Vendedor();
        List<String> lista = listItems.getSelectedValuesList();
        Coordenada c = new Coordenada((double) spnLat.getValue(), (double) spnLong.getValue());
        v.setNombre(txtNombre.getText());
        v.setDireccion(txtDireccion.getText());
        v.setCoordenada(c);
        for (String s : lista) {
            v.addItemMenu(this.obtenerItem(s));
        }

        //v.addItemMenu((obtenerItem((String)cmbItemVendedor.getSelectedItem())));
        listaVendedores.add(v);
        vendedorController.crearVendedor(v);
        iniciarTabla();
        iniciarListaVendedores();
        txtNombre.setText("");
        txtDireccion.setText("");
        spnLat.setValue(0.1);
        spnLong.setValue(0.1);

    }//GEN-LAST:event_btncrearVendedorActionPerformed

    private void btnBorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBorrarActionPerformed
        // TODO add your handling code here:
        modelo.removeRow(tablaVend.getSelectedRow());
    }//GEN-LAST:event_btnBorrarActionPerformed

    private void cmbCategoriaAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbCategoriaAActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbCategoriaAActionPerformed

    private void btnBebidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBebidaActionPerformed
        // TODO add your handling code here:
        panelPlato.setVisible(false);
        panelAlcohol.setVisible(false);
        panelSinAlcohol.setVisible(true);

    }//GEN-LAST:event_btnBebidaActionPerformed

    private void btnAlcoholActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAlcoholActionPerformed
        // TODO add your handling code here:

        panelPlato.setVisible(false);
        panelSinAlcohol.setVisible(false);
        panelAlcohol.setVisible(true);

    }//GEN-LAST:event_btnAlcoholActionPerformed

    private void btnCrearAlcoholActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCrearAlcoholActionPerformed

        // TODO add your handling code here:
        BebidaAlcoholica a = new BebidaAlcoholica();
        Categoria ca = new Categoria(1, (String) cmbCategoriaA.getSelectedItem());
        a.setGraduacionAlcoholica((int) spnnerGraduacion.getValue());
        a.setNombre(txtNombreAlcohol.getText());
        a.setId((int) spnnerIdAlcohol.getValue());
        a.setVolumen((double) spnnerVol.getValue());
        a.setCategoria(ca);
        a.setPrecio((double) spnnerPrecioA.getValue());
        try {
            a.setVendedor(vendedorController.buscarVendedorPorNombre(listVendedorAlcohol.getSelectedValue()));
        } catch (VendedorNoEncontradoException ex) {

        }
        listaAlcohol.add(a);
        listaItem.add(a);
        itemMenuController.crearItemMenu(a);
        iniciarListaItems();
        iniciarTablaAlcohol();
        cmbCategoriaA.setSelectedIndex(0);
        spnnerGraduacion.setValue(0);
        txtNombreAlcohol.setText("");
        spnnerIdAlcohol.setValue(0);
        spnnerVol.setValue(0);
        spnnerPrecioA.setValue(0);

    }//GEN-LAST:event_btnCrearAlcoholActionPerformed

    private void btnBorrarAlcoholActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBorrarAlcoholActionPerformed
        // TODO add your handling code here:
        modeloAlcohol.removeRow(tableAlcohol.getSelectedRow());
    }//GEN-LAST:event_btnBorrarAlcoholActionPerformed

    private void txtNombreClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreClienteActionPerformed

    private void btnCrearClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCrearClienteActionPerformed
        // TODO add your handling code here:
        Coordenada co = new Coordenada((double) SpinnerLongCliente.getValue(), (double) SpinnerLatCliente.getValue());
        Cliente c = new Cliente();
        c.setNombre(txtNombreCliente.getText());
        c.setCuit(txtCuitCliente.getText());
        c.setEmail(txtEmailCliente.getText());
        c.setDireccion(txtDireccionCliente.getText());
        c.setCoordenada(co);
        listaClientes.add(c);
        clienteController.agregarClienteALista(c);
        iniciarTablaCliente();
        iniciarListaClientes();
        txtNombreCliente.setText("");
        txtCuitCliente.setText("");
        txtEmailCliente.setText("");
        txtDireccionCliente.setText("");
        SpinnerLongCliente.setValue(0);
        SpinnerLatCliente.setValue(0);

    }//GEN-LAST:event_btnCrearClienteActionPerformed

    private void btnBebidaSinAlcoholActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBebidaSinAlcoholActionPerformed

        // TODO add your handling code here:
        BebidaSinAlcohol a = new BebidaSinAlcohol();
        if (cmbBoxSinAlcohol.getSelectedItem().equals("CHICA")) {
            a.setTamano(Tamano.CHICA);
        } else if (cmbBoxSinAlcohol.getSelectedItem().equals("MEDIANA")) {
            a.setTamano(Tamano.MEDIANA);
        } else if (cmbBoxSinAlcohol.getSelectedItem().equals("GRANDE")) {
            a.setTamano(Tamano.GRANDE);
        }
        a.setVolumen((double) spnerVolSinAlcohol.getValue());
        a.setId((int) spnIdSinAlcohol.getValue());
        a.setNombre(txtNombreSinAlcohol.getText());
        a.setPrecio((double) spinnerPrecioSinAlcohol.getValue());
        try {
            a.setVendedor(vendedorController.buscarVendedorPorNombre(listVendedorSinAlcohol.getSelectedValue()));
        } catch (VendedorNoEncontradoException ex) {

        }
        listaSinAlcohol.add(a);
        itemMenuController.crearItemMenu(a);
        listaItem.add(a);
        iniciarListaItems();
        iniciarTablaSinAlcohol();

    }//GEN-LAST:event_btnBebidaSinAlcoholActionPerformed

    private void btnBorrarSinAlcoholActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBorrarSinAlcoholActionPerformed
        // TODO add your handling code here:
        modeloSinAlcohol.removeRow(tableSinAlcohol.getSelectedRow());
    }//GEN-LAST:event_btnBorrarSinAlcoholActionPerformed

    private void btnActualizarVendedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarVendedorActionPerformed
        // TODO add your handling code here:
        int fila = tablaVend.getSelectedRow();
        modelo.setValueAt(txtNombre.getText(), fila, 0);
        modelo.setValueAt(txtDireccion.getText(), fila, 1);
        modelo.setValueAt(spinerId.getValue(), fila, 2);
        modelo.setValueAt(listItems.getSelectedValuesList(), fila, 3);
        txtNombre.setText("");
        txtDireccion.setText("");
        spnLat.setValue(0);
        spnLong.setValue(0);
    }//GEN-LAST:event_btnActualizarVendedorActionPerformed

    private void btnActualizarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarClienteActionPerformed
        // TODO add your handling code here:
        int fila = tableCliente.getSelectedRow();
        modeloCliente.setValueAt(txtNombreCliente.getText(), fila, 0);
        modeloCliente.setValueAt(txtCuitCliente.getText(), fila, 1);
        modeloCliente.setValueAt(txtEmailCliente.getText(), fila, 2);
        modeloCliente.setValueAt(txtDireccionCliente.getText(), fila, 3);
        txtNombreCliente.setText("");
        txtCuitCliente.setText("");
        txtEmailCliente.setText("");
        txtDireccionCliente.setText("");
    }//GEN-LAST:event_btnActualizarClienteActionPerformed

    private void btnActualizarAlcoholActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarAlcoholActionPerformed
        // TODO add your handling code here:
        int fila = tableAlcohol.getSelectedRow();
        modeloAlcohol.setValueAt(spnnerGraduacion.getValue(), fila, 0);
        modeloAlcohol.setValueAt(spnnerVol.getValue(), fila, 1);
        modeloAlcohol.setValueAt(spnnerIdAlcohol.getValue(), fila, 2);
        modeloAlcohol.setValueAt(txtNombreAlcohol.getText(), fila, 3);
        modeloAlcohol.setValueAt(spnnerPrecioA.getValue(), fila, 4);

    }//GEN-LAST:event_btnActualizarAlcoholActionPerformed

    private void btnActualizarSinAlcoholActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarSinAlcoholActionPerformed
        // TODO add your handling code here:
        int fila = tableSinAlcohol.getSelectedRow();
        modeloSinAlcohol.setValueAt(cmbBoxSinAlcohol.getSelectedItem(), fila, 0);
        modeloSinAlcohol.setValueAt(spnerVolSinAlcohol.getValue(), fila, 1);
        modeloSinAlcohol.setValueAt(spnIdSinAlcohol.getValue(), fila, 2);
        modeloSinAlcohol.setValueAt(txtNombreSinAlcohol.getText(), fila, 3);
        modeloSinAlcohol.setValueAt(spinnerPrecioSinAlcohol.getValue(), fila, 4);
    }//GEN-LAST:event_btnActualizarSinAlcoholActionPerformed

    private void btnCrearPlatoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCrearPlatoActionPerformed
        // TODO add your handling code here:
        Plato p = new Plato();
        p.setCalorias((int) spinnerCalorias.getValue());
        p.setAptoCeliaco(btnAptoCeliaco.isSelected());
        p.setAptoVegano(btnAptoVegano.isSelected());
        p.setNombre(txtNombrePlato.getText());
        p.setPrecio((double) SpinnerPrecioPlato.getValue());
        try {
            p.setVendedor(vendedorController.buscarVendedorPorNombre((String) listVendedorPlato.getSelectedValue()));
        } catch (VendedorNoEncontradoException ex) {

        }
        listaPlatos.add(p);
        listaItem.add(p);
        itemMenuController.crearItemMenu(p);
        iniciarTablaPlatos();
        iniciarListaItems();

    }//GEN-LAST:event_btnCrearPlatoActionPerformed

    private void btnplatoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnplatoActionPerformed
        // TODO add your handling code here:
        panelSinAlcohol.setVisible(false);
        panelAlcohol.setVisible(false);
        panelPlato.setVisible(true);
    }//GEN-LAST:event_btnplatoActionPerformed

    private void BtnBorrarPlatoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnBorrarPlatoActionPerformed
        // TODO add your handling code here:
        modeloPlato.removeRow(tablaPlato.getSelectedRow());
    }//GEN-LAST:event_BtnBorrarPlatoActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        vendedorABuscar = jTextField1.getText();
        Vendedor vendedorBuscado = new Vendedor();

        try {
            vendedorBuscado = vendedorController.buscarVendedorPorNombre(vendedorABuscar);

            modelo.setRowCount(0);

            if (vendedorBuscado != null) {
                Object[] fila = new Object[]{
                    vendedorBuscado.getNombre(),
                    vendedorBuscado.getDireccion(),};
                modelo.addRow(fila);
            }

        } catch (VendedorNoEncontradoException excep) {
            System.err.println(excep.getMessage());
        };
        tablaVend.setModel(modelo);

    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnLimpiarBusquedaVendedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarBusquedaVendedorActionPerformed
        // TODO add your handling code here:
        iniciarTabla();
    }//GEN-LAST:event_btnLimpiarBusquedaVendedorActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        String clienteABuscar = txtBuscadorCliente.getText();
        Cliente clienteBuscado = new Cliente();

        clienteBuscado = clienteController.buscarPorNombreCliente(clienteABuscar);

        modeloCliente.setRowCount(0);

        if (clienteBuscado != null) {
            Object[] fila = new Object[]{
                clienteBuscado.getNombre(),
                clienteBuscado.getCuit(),
                clienteBuscado.getEmail(),
                clienteBuscado.getDireccion(),};
            modeloCliente.addRow(fila);
        }

        tableCliente.setModel(modeloCliente);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void btnLimpiarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarClienteActionPerformed
        // TODO add your handling code here:
        iniciarTablaCliente();
    }//GEN-LAST:event_btnLimpiarClienteActionPerformed

    private void btnAgregarCarritoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarCarritoActionPerformed
        // TODO add your handling code here:
        listaItemPedido.clear();
        String carrito = listItemsPedido.getSelectedValue();
        ItemPedido p = itemPedidoController.crearItemPedido(0, itemMenuController.buscarItemPorNombre(carrito), (int) spinnerCarrito.getValue());
        listaItemPedido.add(p);

        iniciarTablaCarrito();

    }//GEN-LAST:event_btnAgregarCarritoActionPerformed

    private void btnCrearPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCrearPedidoActionPerformed
        // TODO add your handling code here:
        double aux = 0;
        for (ItemPedido i : listaItemPedido) {
            aux = aux + i.getPrecio();
        }
        Pedido p = new Pedido();
        p.setCliente(clienteController.buscarPorNombreCliente(listClientesPedido.getSelectedValue()));
        p.setPedidoDetalle(listaItemPedido);
        if (cmbBoxFormaPago.getSelectedItem().equals("Transferencia")) {
            aux = (aux * 1.002);
        } else if (cmbBoxFormaPago.getSelectedItem().equals("MercadoPago")) {
            aux = aux * 1.004;
        }
        p.setPrecioTotal(aux);
        pedidoController.getPedidoDAO().agregarPedidoALista(p);
        iniciarTablaPedido();
        while (modeloCarrito.getRowCount() > 0) {
            modeloCarrito.removeRow(0);
        }

    }//GEN-LAST:event_btnCrearPedidoActionPerformed

    private void btnBorrarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBorrarClienteActionPerformed
        // TODO add your handling code here:
        modeloCliente.removeRow(tableCliente.getSelectedRow());
    }//GEN-LAST:event_btnBorrarClienteActionPerformed

    private void btnBuscarAlcoholActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarAlcoholActionPerformed
        // TODO add your handling code here:
        String alcoholABuscar = txtBuscadorAlcohol.getText();
        BebidaAlcoholica alcoholBuscado = new BebidaAlcoholica();

        alcoholBuscado = (BebidaAlcoholica) itemMenuController.buscarItemPorNombre(alcoholABuscar);

        modeloAlcohol.setRowCount(0);

        if (alcoholBuscado != null) {
            Object[] fila = new Object[]{
                alcoholBuscado.getGraduacionAlcoholica(),
                alcoholBuscado.getVolumen(),
                alcoholBuscado.getId(),
                alcoholBuscado.getNombre(),
                alcoholBuscado.getPrecio(),};
            modeloAlcohol.addRow(fila);
        }

        tableAlcohol.setModel(modeloAlcohol);
    }//GEN-LAST:event_btnBuscarAlcoholActionPerformed

    private void btnLimpiarBusquedaAlcoholActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarBusquedaAlcoholActionPerformed
        // TODO add your handling code here:
        iniciarTablaAlcohol();
    }//GEN-LAST:event_btnLimpiarBusquedaAlcoholActionPerformed

    private void btnBuscarSinAlcoholActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarSinAlcoholActionPerformed
        // TODO add your handling code here:
        String sinAlcoholABuscar = txtBuscadorSinAlcohol.getText();
        BebidaSinAlcohol alcoholBuscado = new BebidaSinAlcohol();

        alcoholBuscado = (BebidaSinAlcohol) itemMenuController.buscarItemPorNombre(sinAlcoholABuscar);

        modeloSinAlcohol.setRowCount(0);

        if (alcoholBuscado != null) {
            Object[] fila = new Object[]{
                alcoholBuscado.getTamano(),
                alcoholBuscado.getVolumen(),
                alcoholBuscado.getId(),
                alcoholBuscado.getNombre(),
                alcoholBuscado.getPrecio(),};
            modeloSinAlcohol.addRow(fila);
        }

        tableSinAlcohol.setModel(modeloSinAlcohol);
    }//GEN-LAST:event_btnBuscarSinAlcoholActionPerformed

    private void btnLimpiarSinAlcoholActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarSinAlcoholActionPerformed
        // TODO add your handling code here:
        iniciarTablaSinAlcohol();
    }//GEN-LAST:event_btnLimpiarSinAlcoholActionPerformed

    private void btnBorrarPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBorrarPedidoActionPerformed
        // TODO add your handling code here:
        modeloPedido.removeRow(tablaPedido.getSelectedRow());
    }//GEN-LAST:event_btnBorrarPedidoActionPerformed

    private void btnActualizarPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarPedidoActionPerformed
        // TODO add your handling code here:
        int fila = tableCliente.getSelectedRow();
        double aux = 0;
        for (ItemPedido i : listaItemPedido) {
            aux = aux + i.getPrecio();
        }
        if (cmbBoxFormaPago.getSelectedItem().equals("Transferencia")) {
            aux = (aux * 1.002);
        } else if (cmbBoxFormaPago.getSelectedItem().equals("MercadoPago")) {
            aux = aux * 1.004;
        }
        modeloPedido.setValueAt(clienteController.buscarPorNombreCliente(listClientesPedido.getSelectedValue()).getNombre(), fila, 0);
        modeloPedido.setValueAt(aux, fila, 1);
        modeloPedido.setValueAt(listaItemPedido, fila, 2);

    }//GEN-LAST:event_btnActualizarPedidoActionPerformed

    private void btnBuscarPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarPedidoActionPerformed
        // TODO add your handling code here:
        String clienteABuscar = listClientesPedido.getSelectedValue();
        Pedido pedidoBuscado = new Pedido();

        pedidoBuscado = pedidoController.buscarPorNombreCliente(clienteController.buscarPorNombreCliente(clienteABuscar).getNombre());

        modeloPedido.setRowCount(0);

        if (pedidoBuscado != null) {
            Object[] fila = new Object[]{
                pedidoBuscado.getCliente().getNombre(),
                pedidoBuscado.getPrecioTotal(),
                pedidoBuscado.getPedidoDetalle(),};
            modeloPedido.addRow(fila);
        }

        tablaPedido.setModel(modeloPedido);
    }//GEN-LAST:event_btnBuscarPedidoActionPerformed

    private void btnLimpiarBusquedaPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarBusquedaPedidoActionPerformed
        // TODO add your handling code here:
        iniciarTablaPedido();
    }//GEN-LAST:event_btnLimpiarBusquedaPedidoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Inicio().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnActualizarPlato;
    private javax.swing.JButton BtnBorrarPlato;
    private javax.swing.JSpinner SpinnerLatCliente;
    private javax.swing.JSpinner SpinnerLongCliente;
    private javax.swing.JSpinner SpinnerPrecioPlato;
    private javax.swing.JButton btnActualizarAlcohol;
    private javax.swing.JButton btnActualizarCliente;
    private javax.swing.JButton btnActualizarPedido;
    private javax.swing.JButton btnActualizarSinAlcohol;
    private javax.swing.JButton btnActualizarVendedor;
    private javax.swing.JButton btnAgregarCarrito;
    private javax.swing.JRadioButton btnAlcohol;
    private javax.swing.JToggleButton btnAptoCeliaco;
    private javax.swing.JToggleButton btnAptoVegano;
    private javax.swing.JRadioButton btnBebida;
    private javax.swing.JButton btnBebidaSinAlcohol;
    private javax.swing.JButton btnBorrar;
    private javax.swing.JButton btnBorrarAlcohol;
    private javax.swing.JButton btnBorrarCliente;
    private javax.swing.JButton btnBorrarPedido;
    private javax.swing.JButton btnBorrarSinAlcohol;
    private javax.swing.JButton btnBuscarAlcohol;
    private javax.swing.JButton btnBuscarPedido;
    private javax.swing.JButton btnBuscarSinAlcohol;
    private javax.swing.JButton btnCrearAlcohol;
    private javax.swing.JButton btnCrearCliente;
    private javax.swing.JButton btnCrearPedido;
    private javax.swing.JButton btnCrearPlato;
    private javax.swing.JButton btnLimpiarBusquedaAlcohol;
    private javax.swing.JButton btnLimpiarBusquedaPedido;
    private javax.swing.JButton btnLimpiarBusquedaVendedor;
    private javax.swing.JButton btnLimpiarCliente;
    private javax.swing.JButton btnLimpiarSinAlcohol;
    private javax.swing.JButton btncrearVendedor;
    private javax.swing.JRadioButton btnplato;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> cmbBoxFormaPago;
    private javax.swing.JComboBox<String> cmbBoxSinAlcohol;
    private javax.swing.JComboBox<String> cmbCategoriaA;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JList<String> listClientesPedido;
    private javax.swing.JList<String> listItems;
    private javax.swing.JList<String> listItemsPedido;
    private javax.swing.JList<String> listVendedorAlcohol;
    private javax.swing.JList<String> listVendedorPlato;
    private javax.swing.JList<String> listVendedorSinAlcohol;
    private javax.swing.JPanel panelAlcohol;
    private javax.swing.JPanel panelPlato;
    private javax.swing.JPanel panelSinAlcohol;
    private javax.swing.JSpinner spinerId;
    private javax.swing.JSpinner spinnerCalorias;
    private javax.swing.JSpinner spinnerCarrito;
    private javax.swing.JSpinner spinnerPrecioSinAlcohol;
    private javax.swing.JSpinner spnIdSinAlcohol;
    private javax.swing.JSpinner spnLat;
    private javax.swing.JSpinner spnLong;
    private javax.swing.JSpinner spnerVolSinAlcohol;
    private javax.swing.JSpinner spnnerGraduacion;
    private javax.swing.JSpinner spnnerIdAlcohol;
    private javax.swing.JSpinner spnnerPrecioA;
    private javax.swing.JSpinner spnnerVol;
    private javax.swing.JTable tablaCarrito;
    private javax.swing.JTable tablaPedido;
    private javax.swing.JTable tablaPlato;
    private javax.swing.JTable tablaVend;
    private javax.swing.JTable tableAlcohol;
    private javax.swing.JTable tableCliente;
    private javax.swing.JTable tableSinAlcohol;
    private javax.swing.JTextField txtBuscadorAlcohol;
    private javax.swing.JTextField txtBuscadorCliente;
    private javax.swing.JTextField txtBuscadorPedido;
    private javax.swing.JTextField txtBuscadorPlato;
    private javax.swing.JTextField txtBuscadorSinAlcohol;
    private javax.swing.JTextField txtCuitCliente;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtDireccionCliente;
    private javax.swing.JTextField txtEmailCliente;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtNombreAlcohol;
    private javax.swing.JTextField txtNombreCliente;
    private javax.swing.JTextField txtNombrePlato;
    private javax.swing.JTextField txtNombreSinAlcohol;
    // End of variables declaration//GEN-END:variables

    private void iniciarTabla() {
        while (modelo.getRowCount() > 0) {
            modelo.removeRow(0);
        }

        for (Vendedor vend : vendedorController.mostrarListaVendedor()) {
            Object o[] = new Object[4];
            o[0] = vend.getNombre();
            o[1] = vend.getDireccion();
            o[2] = vend.getId();
            o[3] = vend.getItems();
            modelo.addRow(o);
        }
        tablaVend.setModel(modelo);

    }

    private void iniciarTablaAlcohol() {
        while (modeloAlcohol.getRowCount() > 0) {
            modeloAlcohol.removeRow(0);
        }
        for (BebidaAlcoholica a : listaAlcohol) {

            Object o[] = new Object[7];
            o[0] = a.getGraduacionAlcoholica();
            o[1] = a.getVolumen();
            o[2] = a.getId();
            o[3] = a.getNombre();
            o[4] = a.getPrecio();
            o[5] = a.getCategoria();
            o[6] = a.getVendedor().getNombre();
            modeloAlcohol.addRow(o);
        }
        tableAlcohol.setModel(modeloAlcohol);

    }

    private void iniciarTablaCliente() {
        while (modeloCliente.getRowCount() > 0) {
            modeloCliente.removeRow(0);
        }
        for (Cliente a : clienteController.listarClientes()) {

            Object o[] = new Object[5];
            o[0] = a.getNombre();
            o[1] = a.getCuit();
            o[2] = a.getEmail();
            o[3] = a.getDireccion();
            o[4] = a.getCoordenada();

            modeloCliente.addRow(o);
        }
        tableCliente.setModel(modeloCliente);

    }

    public ItemMenu obtenerItem(String n) {
        for (ItemMenu i : listaItem) {
            if (n.equals(i.getNombre())) {
                return i;
            }
        }
        return null;

    }

    private void iniciarListaItems() {
        modeloListaItemVendedor.clear();
        for (ItemMenu a : itemMenuController.getItemMenuDAO().listarItemMenu()) {

            modeloListaItemVendedor.addElement(a.toString());
        }

        listItems.setModel(modeloListaItemVendedor);
        listItemsPedido.setModel(modeloListaItemVendedor);

    }

    private void iniciarTablaSinAlcohol() {
        while (modeloSinAlcohol.getRowCount() > 0) {
            modeloSinAlcohol.removeRow(0);
        }
        for (BebidaSinAlcohol a : listaSinAlcohol) {

            Object o[] = new Object[6];
            o[0] = a.getTamano();
            o[1] = a.getVolumen();
            o[2] = a.getId();
            o[3] = a.getNombre();
            o[4] = a.getPrecio();
            o[5] = a.getVendedor().getNombre();

            modeloSinAlcohol.addRow(o);
        }
        tableSinAlcohol.setModel(modeloSinAlcohol);

    }

    private void iniciarTablaPlatos() {
        while (modeloPlato.getRowCount() > 0) {
            modeloPlato.removeRow(0);
        }
        for (Plato a : listaPlatos) {

            Object o[] = new Object[6];
            o[0] = a.getCalorias();
            o[1] = a.getAptoCeliaco();
            o[2] = a.getAptoVegano();
            o[3] = a.getNombre();
            o[4] = a.getPrecio();
            o[5] = a.getVendedor().getNombre();

            modeloPlato.addRow(o);
        }
        tablaPlato.setModel(modeloPlato);

    }

    private void iniciarTablaCarrito() {
        while (modeloCarrito.getRowCount() > 0) {
            modeloCarrito.removeRow(0);
        }
        for (ItemPedido a : listaItemPedido) {

            Object o[] = new Object[3];
            o[0] = a.getItemMenu().getNombre();
            o[1] = a.getCantidad();
            o[2] = a.getPrecio();

            modeloCarrito.addRow(o);
        }
        tablaCarrito.setModel(modeloCarrito);

    }

    private void iniciarListaClientes() {
        modeloListaClientePedido.clear();
        for (Cliente c : clienteController.getClienteDAO().listarClientes()) {
            modeloListaClientePedido.addElement(c.getNombre());
        }
        listClientesPedido.setModel(modeloListaClientePedido);
    }

    private void iniciarTablaPedido() {
        while (modeloPedido.getRowCount() > 0) {
            modeloPedido.removeRow(0);
        }
        for (Pedido a : pedidoController.getPedidoDAO().getListaPedidos()) {

            Object o[] = new Object[3];
            o[0] = a.getCliente().getNombre();
            o[1] = a.getPrecioTotal();
            o[2] = a.getPedidoDetalle();

            modeloPedido.addRow(o);
        }
        tablaPedido.setModel(modeloPedido);
    }

    private void iniciarListaVendedores() {
        modeloListaVendedorItem.clear();
        for (Vendedor c : vendedorController.mostrarListaVendedor()) {
            modeloListaVendedorItem.addElement(c.getNombre());
        }
        listVendedorAlcohol.setModel(modeloListaVendedorItem);
        listVendedorSinAlcohol.setModel(modeloListaVendedorItem);
        listVendedorPlato.setModel(modeloListaVendedorItem);
    }

}
