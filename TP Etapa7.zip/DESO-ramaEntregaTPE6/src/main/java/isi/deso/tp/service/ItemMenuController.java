package isi.deso.tp.service;

import isi.deso.tp.dao.ItemMenuDAO;
import isi.deso.tp.model.Bebida;
import isi.deso.tp.model.BebidaAlcoholica;
import isi.deso.tp.model.BebidaSinAlcohol;
import isi.deso.tp.model.Categoria;
import isi.deso.tp.model.ItemMenu;
import isi.deso.tp.model.Plato;
import isi.deso.tp.model.Tamano;
import isi.deso.tp.model.Vendedor;
import java.util.ArrayList;
import java.util.List;

public class ItemMenuController {
    private ItemMenuDAO itemMenuDAO;
    
    public ItemMenuController(ItemMenuDAO itemMenuDAO){
        this.itemMenuDAO = itemMenuDAO;
    }
    
    public ItemMenuDAO getItemMenuDAO() {
        return itemMenuDAO;
    }

    public void setItemMenuDAO(ItemMenuDAO itemMenuDAO) {
        this.itemMenuDAO = itemMenuDAO;
    }
    
    public void crearItemMenu(ItemMenu itemMenu) {
        this.itemMenuDAO.crearItemMenu(itemMenu);
    }
    
    public ItemMenu crearNuevBebidaAlcoholica(int graduacionAlcoholica, Tamano tamano, double volumen, int id, String nombre, String descripcion, double precio, Categoria categoria, Vendedor vendedor){
        ItemMenu itemMenu = new BebidaAlcoholica(graduacionAlcoholica, tamano, volumen, id, nombre, descripcion, precio, categoria, vendedor);
        this.itemMenuDAO.crearItemMenu(itemMenu);
        return itemMenu;
    }
    
    public ItemMenu crearNuevaBebidaSinAlcohol(Tamano tamano, double volumen, int id, String nombre, String descripcion, double precio, Categoria categoria, Vendedor vendedor){
        ItemMenu itemMenu = new BebidaSinAlcohol(tamano, volumen, id, nombre, descripcion, precio, categoria, vendedor);
        this.itemMenuDAO.crearItemMenu(itemMenu);
        return itemMenu;
    }
    
    public ItemMenu crearNuevoPlato(int calorias, boolean aptoCeliaco, boolean aptoVegano, int id, String nombre, String descripcion, double precio, Categoria categoria, double peso, Vendedor vendedor){
        ItemMenu itemMenu = new Plato(calorias,  aptoCeliaco,  aptoVegano,  id,  nombre,  descripcion,  precio,  categoria,  peso,  vendedor);
        this.itemMenuDAO.crearItemMenu(itemMenu);
        return itemMenu;
    }
    
    public List<ItemMenu> filtrarBebidas(List<ItemMenu> itemsMenu){
        List<ItemMenu> bebidas = new ArrayList<>();
        for(ItemMenu i : itemsMenu){
            if(i.esBebida()){
                bebidas.add(i);
            }
        }
        return bebidas;
    }
    
    public List<ItemMenu> filtrarPlatos(List<ItemMenu> itemsMenu){
        List<ItemMenu> platos = new ArrayList<>();
        for(ItemMenu i : itemsMenu){
            if(i.esComida()){
                platos.add(i);
            }
        }
        return platos;
    }
    
    public List<ItemMenu> buscarItemMenu(int idItemMenu) {
        return this.itemMenuDAO.listarItemMenu().stream().filter(itemMenu -> itemMenu.getId() == idItemMenu).toList();
    }
    
    public void actualizarItemMenu(ItemMenu itemMenu) {
        this.itemMenuDAO.listarItemMenu().remove(itemMenu.getId());
        this.itemMenuDAO.listarItemMenu().add(itemMenu);
    }
    
    public void eliminarItemMenu(int idItemMenu) {
        this.itemMenuDAO.listarItemMenu().remove(idItemMenu);
    }
    
    public ItemMenu buscarItemPorNombre(String nombre){
        return this.itemMenuDAO.buscarItemPorNombre(nombre);
    }
}
